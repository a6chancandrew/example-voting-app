/*
  Copyright (c) 2003-2019, YourKit
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

  * Neither the name of YourKit nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY YOURKIT "AS IS" AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL YOURKIT BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.yourkit.probes.builtin;

import com.yourkit.probes.*;
import com.yourkit.runtime.CallbackProxy;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.yourkit.probes.ReflectionUtil.*;

public final class MongoDB {
  public static final String TABLE_NAME = "MongoDB";

  private static final class RequestTable extends Table {
    private final StringColumn myType = new StringColumn("Type");
    private final StringColumn myDetail = new StringColumn("Detail");
    private final LongColumn myLatencyMs = new LongColumn("Latency (ms)");

    public RequestTable() {
      super(MongoDB.class, TABLE_NAME, Table.MASK_FOR_LASTING_EVENTS);
    }
  }
  private static final RequestTable T_REQUESTS = new RequestTable();

  private static final WeakHashMap<Object, RequestData> ourCallback2RequestData = new WeakHashMap<>();

  @MethodPattern({
    // since 3.8
    "com.mongodb.client.internal.MongoClientDelegate$DelegateOperationExecutor : execute(com.mongodb.operation.ReadOperation, com.mongodb.ReadPreference, com.mongodb.ReadConcern, com.mongodb.client.ClientSession)",
    // since 3.7
    "com.mongodb.client.internal.MongoClientDelegate$DelegateOperationExecutor : execute(com.mongodb.operation.ReadOperation, com.mongodb.ReadPreference, com.mongodb.session.ClientSession)",
    // since 3.6
    "com.mongodb.Mongo$* : execute(com.mongodb.operation.ReadOperation, com.mongodb.ReadPreference, com.mongodb.session.ClientSession)",
    // since 3.0
    "com.mongodb.Mongo : execute(com.mongodb.operation.ReadOperation, com.mongodb.ReadPreference)"
  })
  public static final class ExecuteReadOperation {
    public static int onEnter(@Param(1) final Object operation) {
      return enter(operation, null, false);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @MethodTimeMs final long methodTimeMs, @ThrownException @Nullable final Throwable e) {
      exit(rowIndex, methodTimeMs, null, e);
    }
  }

  @MethodPattern({
    // since 3.8
    "com.mongodb.client.internal.MongoClientDelegate$DelegateOperationExecutor : execute(com.mongodb.operation.WriteOperation, com.mongodb.ReadConcern, com.mongodb.client.ClientSession)",
    // since 3.7
    "com.mongodb.client.internal.MongoClientDelegate$DelegateOperationExecutor : execute(com.mongodb.operation.WriteOperation, com.mongodb.session.ClientSession)",
    // since 3.6
    "com.mongodb.Mongo$* : execute(com.mongodb.operation.WriteOperation, com.mongodb.session.ClientSession)",
    // since 3.0
    "com.mongodb.Mongo : execute(com.mongodb.operation.WriteOperation)"
  })
  public static final class ExecuteWriteOperation {
    public static int onEnter(@Param(1) final Object operation) {
      return enter(operation, null, true);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @MethodTimeMs final long methodTimeMs, @ThrownException @Nullable final Throwable e) {
      exit(rowIndex, methodTimeMs, null, e);
    }
  }

  @MethodPattern("com.mongodb.operation.* : executeAsync(com.mongodb.binding.AsyncReadBinding, com.mongodb.async.SingleResultCallback)")
  public static final class ExecuteAsyncRead {
    public static int onEnter(@This final Object operation, @Param(2) final Object callback) {
      return enter(operation, callback, false);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @Param(2) final Object callback, @ThrownException @Nullable final Throwable e) {
      exit(rowIndex, 0, callback, e);
    }
  }

  @MethodPattern("com.mongodb.operation.* : executeAsync(com.mongodb.binding.AsyncWriteBinding, com.mongodb.async.SingleResultCallback)")
  public static final class ExecuteAsyncWrite {
    public static int onEnter(@This final Object operation, @Param(2) final Object callback) {
      return enter(operation, callback, true);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @Param(2) final Object callback, @ThrownException @Nullable final Throwable e) {
      exit(rowIndex, 0, callback, e);
    }
  }

  @MethodPattern({
    // since 3.8
    "com.mongodb.async.client.OperationExecutorImpl$* : onResult(Object, java.lang.Throwable)",
    // since 3.6
    "com.mongodb.async.client.AsyncOperationExecutorImpl$* : onResult(Object, java.lang.Throwable)",
    // since 3.0
    "com.mongodb.async.client.MongoClientImpl$* : onResult(Object, java.lang.Throwable)"
  })
  public static final class CallbackResult {
    public static void onEnter(@This final Object callback) {
      final RequestData requestData;
      synchronized (ourCallback2RequestData) {
        requestData = ourCallback2RequestData.remove(callback);
      }
      if (requestData != null) {
        T_REQUESTS.myLatencyMs.setValue(requestData.myRowIndex, CallbackProxy.getInstance().getUptimeMs() - requestData.myStartMs);
      }
    }
  }

  // common code

  private static final ThreadLocal<boolean[]> ourInsideTopCall = new ThreadLocal<boolean[]>() {
    @Override
    protected boolean[] initialValue() {
      return new boolean[1];
    }
  };

  static final class OperationTypeMap extends HashMap<String, String> {
    /**
     * sic: parameter order is (value, key) for readability!
     */
    OperationTypeMap append(@NotNull final String type, @NotNull final String className) {
      put(className, type);
      return this;
    }
  }

  static final OperationTypeMap ourReadOperation2Type = new OperationTypeMap()
    .append("aggregate", "com.mongodb.operation.AggregateOperation")
    .append("aggregate", "com.mongodb.operation.AggregateExplainOperation")

    .append("count", "com.mongodb.operation.CountOperation")
    .append("find", "com.mongodb.operation.FindOperation")

    .append("list", "com.mongodb.operation.ListDatabasesOperation")
    .append("list", "com.mongodb.operation.ListIndexesOperation")
    .append("list", "com.mongodb.operation.ListCollectionsOperation")

    .append("mapReduce", "com.mongodb.operation.MapReduceWithInlineResultsOperation")

    .append("distinct", "com.mongodb.operation.DistinctOperation");

  static final OperationTypeMap ourWriteOperation2Type = new OperationTypeMap()
    .append("createIndex", "com.mongodb.operation.CreateIndexesOperation")

    .append("createCollection", "com.mongodb.operation.CreateCollectionOperation")

    .append("update", "com.mongodb.operation.UpdateOperation")
    .append("update", "com.mongodb.operation.FindAndUpdateOperation")

    .append("replace", "com.mongodb.operation.FindAndReplaceOperation")

    .append("insert", "com.mongodb.operation.InsertOperation")

    .append("aggregate (write)", "com.mongodb.operation.AggregateToCollectionOperation") // write operation

    .append("mapReduce (write)", "com.mongodb.operation.MapReduceToCollectionOperation")  // write operation

    .append("delete", "com.mongodb.operation.DeleteOperation")
    .append("delete", "com.mongodb.operation.FindAndDeleteOperation")

    .append("drop", "com.mongodb.operation.DropCollectionOperation")
    .append("drop", "com.mongodb.operation.DropDatabaseOperation")
    .append("drop", "com.mongodb.operation.DropIndexOperation")
    .append("drop", "com.mongodb.operation.DropUserOperation");

  static final OperationTypeMap ourWriteRequestToType = new OperationTypeMap()
    .append("insert", "com.mongodb.InsertRequest")
    .append("insert", "com.mongodb.bulk.InsertRequest")

    .append("update", "com.mongodb.UpdateRequest")
    .append("update", "com.mongodb.bulk.UpdateRequest")

    .append("delete", "com.mongodb.DeleteRequest")
    .append("delete", "com.mongodb.bulk.DeleteRequest")

    .append("replace", "com.mongodb.ReplaceRequest")
    .append("replace", "com.mongodb.bulk.ReplaceRequest");

  private static int enter(
    @Nullable final Object operation,
    @Nullable final Object asyncCallback,
    final boolean isWrite
  ) {
    if (operation == null) {
      // impossible?
      return Table.NO_ROW;
    }
    if (ourInsideTopCall.get()[0]) {
      // already entered
      return Table.NO_ROW;
    }
    ourInsideTopCall.get()[0] = true;

    final int rowIndex = T_REQUESTS.createRow();
    if (Table.shouldIgnoreRow(rowIndex)) {
      // optimization
      return Table.NO_ROW;
    }

    final String operationClassName = operation.getClass().getName();

    final String eventType;
    String description = null;
    if (isWrite) {
      // WriteOperation

      if (operationClassName.endsWith("MixedBulkWriteOperation")) {
        final List requests = (List)callMethod0(operation, "getWriteRequests:()Ljava/util/List;");
        if (requests != null) {
          final int size = requests.size();
          if (size == 1) {
            final Object request = requests.get(0);
            final String requestClassName = request.getClass().getName();

            final String type = ourWriteRequestToType.get(requestClassName);
            if (type != null) {
              eventType = type;
              description = getRequestDescription(request, requestClassName);
            }
            else {
              eventType = getDescriptionForObject(request);
            }
          }
          else {
            eventType = "bulkWrite";
            description = "count=" + size;
          }
        }
        else {
          eventType = "(other write)";
        }
      }
      else {
        final String type = ourWriteOperation2Type.get(operationClassName);
        eventType = type != null ? type : "(other write)";
      }
    }
    else {
      // ReadOperation

      if (operationClassName.endsWith("CommandReadOperation")) {
        final Object doc = getFieldValue(operation, "command:Lorg/bson/BsonDocument;");
        if (doc != null) {
          description = getDescriptionForObject(doc);
        }
      }

      final String type = ourReadOperation2Type.get(operationClassName);
      eventType = type != null ? type : "(other read)";
    }

    if (description == null) {
      description = getDocDescriptionViaGetFilter(operation);
    }

    final String namespace = getNamespaceFromOperation(operation);

    T_REQUESTS.myType.setValue(rowIndex, eventType);
    T_REQUESTS.myDetail.setValue(rowIndex, (namespace != null ? "[" + namespace + "] " : "") + description);

    if (asyncCallback != null) {
      synchronized (ourCallback2RequestData) {
        ourCallback2RequestData.put(asyncCallback, new RequestData(rowIndex));
      }
    }

    return rowIndex;
  }

  private static void exit(
    final int rowIndex,
    final long syncMethodTimeMs,
    @Nullable final Object asyncCallback,
    @Nullable final Throwable e
  ) {
    if (Table.shouldIgnoreRow(rowIndex)) {
      return;
    }
    ourInsideTopCall.get()[0] = false;
    if (asyncCallback == null) {
      T_REQUESTS.myLatencyMs.setValue(rowIndex, syncMethodTimeMs);
    }
    else if (e != null) {
      synchronized (ourCallback2RequestData) {
        ourCallback2RequestData.remove(asyncCallback);
      }
    }
    T_REQUESTS.closeRow(rowIndex, e);
  }

  @NotNull
  private static String getDocDescriptionViaGetFilter(@NotNull final Object operation) {
    final Object doc = callMethod0(operation, "getFilter:()Lorg/bson/BsonDocument;");
    return doc != null ? getDescriptionForObject(doc) : "{}";
  }

  @NotNull
  private static String getRequestDescription(@NotNull final Object request, @NotNull final String requestClassName) {
    final Object doc;
    if ("com.mongodb.bulk.InsertRequest".equals(requestClassName)) {
      doc = callMethod0(request, "getDocument:()Lorg/bson/BsonDocument;");
    }
    else {
      doc = callMethod0(request, "getFilter:()Lorg/bson/BsonDocument;");
    }
    return doc != null ? getDescriptionForObject(doc) : "{}";
  }

  @NotNull
  private static String getDescriptionForObject(@NotNull final Object descriptionObject) {
    if (descriptionObject instanceof String) {
      return (String)descriptionObject;
    }

    if (descriptionObject instanceof Map) {
      final Set<?> keySet = ((Map)descriptionObject).keySet();
      if (keySet.isEmpty()) {
        // optimization
        return "{}";
      }

      final StringBuilder result = new StringBuilder();
      result.append('{');

      for (final Object key : keySet) {
        if (!(key instanceof String)) {
          continue;
        }

        if (result.length() > 1) {
          result.append(", ");
        }
        result.append(key);
      }

      result.append('}');

      return result.toString();
    }

    if (descriptionObject instanceof List) {
      return "count=" + ((List)descriptionObject).size();
    }

    final String descriptionObjectClassName = descriptionObject.getClass().getName();
    if (descriptionObjectClassName.endsWith("SimpleEncodingFilter")) {
      final String fieldName = getFieldValue(descriptionObject, "fieldName:" + STRING_SIG);
      if (fieldName != null) {
        return "{" + fieldName + "}";
      }
    }

    return descriptionObjectClassName;
  }

  @Nullable
  static String getNamespaceFromOperation(@NotNull final Object operation) {
    Object namespace = getFieldValue(operation, "namespace:Lcom/mongodb/MongoNamespace;");
    if (namespace == null) {
      namespace = callMethod0(operation, "getNamespace:()Lcom/mongodb/MongoNamespace;");
    }
    if (namespace != null) {
      final String name = callMethod0String(namespace, "getFullName");
      if (name != null) {
        return name;
      }
    }

    final String databaseName = getFieldValue(operation, "databaseName:" + STRING_SIG);
    final String collectionName = getFieldValue(operation, "collectionName:" + STRING_SIG);

    if (databaseName == null && collectionName == null) {
      return null;
    }

    if (databaseName != null && collectionName != null) {
      return databaseName + "." + collectionName;
    }

    return collectionName == null ? databaseName : collectionName;
  }

  private static final class RequestData {
    private final long myStartMs;
    private final int myRowIndex;

    public RequestData(final int rowIndex) {
      myStartMs = CallbackProxy.getInstance().getUptimeMs();
      myRowIndex = rowIndex;
    }
  }
}
