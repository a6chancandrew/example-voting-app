/*
  Copyright (c) 2003-2019, YourKit
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

  * Neither the name of YourKit nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY YOURKIT "AS IS" AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL YOURKIT BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.yourkit.probes.builtin;

import com.yourkit.probes.*;
import com.yourkit.util.Strings;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.List;

import static com.yourkit.probes.ReflectionUtil.*;

public class Cassandra {
  public static final String TABLE_NAME = "Cassandra";

  private static final class RequestTable extends Table {
    private final StringColumn myType = new StringColumn("Type");
    private final StringColumn myDetail = new StringColumn("Detail");
    private final LongColumn myLatencyMs = new LongColumn("Latency (ms)");

    public RequestTable() {
      super(Cassandra.class, TABLE_NAME, Table.MASK_FOR_LASTING_EVENTS);
    }
  }

  private static final RequestTable T_REQUESTS = new RequestTable();

  private static final ObjectRowIndexMap<Object> ourCallback2Row = new ObjectRowIndexMap<>();

  private static final ThreadLocal<int[]> ourTopSynchronousRow = new ThreadLocal<int[]>() {
    @Override
    protected int[] initialValue() {
      return new int[1];
    }
  };

  @MethodPattern({
    "com.datastax.driver.core.AbstractSession:execute(com.datastax.driver.core.Statement)",
    "com.datastax.driver.core.AbstractSession:prepare(String)",
    "com.datastax.driver.core.AbstractSession:prepare(com.datastax.driver.core.RegularStatement)"
  })
  public static final class SynchronousOperations {
    public static int onEnter() {
      final int row = T_REQUESTS.createRow();
      if (Table.shouldIgnoreRow(row)) {
        return Table.NO_ROW;
      }
      ourTopSynchronousRow.get()[0] = row;
      return row;
    }

    public static void onExit(@OnEnterResult final int row, @ThrownException @Nullable final Throwable e) {
      if (Table.shouldIgnoreRow(row)) {
        return;
      }
      ourTopSynchronousRow.get()[0] = Table.NO_ROW;
      T_REQUESTS.closeRow(row, e);
    }
  }

  /**
   * Optimization: don't create temporary strings
   */
  static final HashMap<String, String> ourRequestTypeLowerCase = new HashMap<>();
  static {
    ourRequestTypeLowerCase.put("EXECUTE", "execute");
    ourRequestTypeLowerCase.put("PREPARE", "prepare");
    ourRequestTypeLowerCase.put("STARTUP", "startup");
    ourRequestTypeLowerCase.put("CREDENTIALS", "credentials");
    ourRequestTypeLowerCase.put("OPTIONS", "options");
    ourRequestTypeLowerCase.put("QUERY", "query");
    ourRequestTypeLowerCase.put("REGISTER", "register");
    ourRequestTypeLowerCase.put("BATCH", "batch");
    ourRequestTypeLowerCase.put("AUTH_RESPONSE", "auth_response");
  }

  @MethodPattern("com.datastax.driver.core.RequestHandler:<init>(*)")
  public static final class RequestInit {
    public static void onEnter(@Param(2) final Object callback, @Param(3) final Object statement) {
      if (callback == null) {
        return;
      }

      final Object request = callMethod0(callback, "request:()Lcom/datastax/driver/core/Message$Request;");
      if (request == null) {
        processRequest(callback, null, null);
        return;
      }

      final Object type = getFieldValue(request, "type:Lcom/datastax/driver/core/Message$Request$Type;");
      if (!(type instanceof Enum)) {
        processRequest(callback, null, null);
        return;
      }

      final String typeNameUpperCase = ((Enum)type).name();
      String typeName = ourRequestTypeLowerCase.get(typeNameUpperCase);
      if (typeName == null) {
        typeName = typeNameUpperCase.toLowerCase();
      }

      final String detail;
      if ("query".equals(typeName) || "prepare".equals(typeName)) {
        detail = getFieldValue(request, "query:" + STRING_SIG);
      }
      else if ("execute".equals(typeName) || "batch".equals(typeName)) {
        detail = tryGetQueryString(statement);
      }
      else {
        detail = ""; // no detail
      }

      processRequest(callback, typeName, detail);
    }
  }

  private static void processRequest(@Nullable final Object callback, @Nullable final String type, @Nullable final String detail) {
    int row = ourTopSynchronousRow.get()[0];
    if (Table.shouldIgnoreRow(row)) {
      // Asynchronous request
      row = T_REQUESTS.createRow();
      T_REQUESTS.closeRow(row, null);
    }

    T_REQUESTS.myType.setValue(row, Strings.notNull(type, "<unknown>"));
    T_REQUESTS.myDetail.setValue(row, Strings.notNull(detail, "<unknown>"));

    if (callback != null) {
      ourCallback2Row.put(callback, row);
    }
  }

  @MethodPattern(
    "com.datastax.driver.*:onSet(" +
    "com.datastax.driver.core.Connection, " +
    "com.datastax.driver.core.Message$Response, " +
    "com.datastax.driver.core.ExecutionInfo, " +
    "com.datastax.driver.core.Statement," +
    "long)"
  )
  public static final class onSet5 {
    public static void onReturn(@This final Object callback, @Param(5) final long latencyNs) {
      setResults(callback, latencyNs, null);
    }
  }

  @MethodPattern(
    "com.datastax.driver.*:onSet(" +
    "com.datastax.driver.core.Connection, " +
    "com.datastax.driver.core.Message$Response, " +
    "long, int)"
  )
  public static final class onSet4 {
    public static void onReturn(@This final Object callback, @Param(3) final long latencyNs) {
      setResults(callback, latencyNs, null);
    }
  }

  @MethodPattern(
    "com.datastax.driver.*:onException(" +
    "com.datastax.driver.core.Connection, " +
    "java.lang.Exception, " +
    "long, int)"
  )
  public static final class onException {
    public static void onReturn(@This final Object callback, @Param(2) final Exception e, @Param(3) final long latencyNs) {
      setResults(callback, latencyNs, e);
    }
  }

  @MethodPattern(
    "com.datastax.driver.*:onTimeout(" +
    "com.datastax.driver.core.Connection, " +
    "long, int)"
  )
  public static final class onTimeout {
    public static void onReturn(@This final Object callback, @Param(2) final long latencyNs) {
      setResults(callback, latencyNs, null);
    }
  }

  private static void setResults(@NotNull final Object callback, final long latencyNs, @Nullable final Throwable e) {
    final int row = ourCallback2Row.remove(callback);
    if (Table.shouldIgnoreRow(row)) {
      return;
    }
    if (e != null) {
      T_REQUESTS.setEventTableRowException(row, e);
    }
    T_REQUESTS.myLatencyMs.setValue(row, latencyNs / 1000000);
  }

  @NotNull
  static String tryGetQueryString(@Nullable final Object query) {
    if (query == null) {
      return "<unknown>";
    }

    if (query instanceof String) {
      return (String)query;
    }

    final String className = query.getClass().getName();

    if (className.equals("com.datastax.driver.core.BoundStatement")) {
      return tryGetQueryString(getFieldValue(query, "statement:Lcom/datastax/driver/core/PreparedStatement;"));
    }

    if (className.equals("com.datastax.driver.core.DefaultPreparedStatement")) {
      return tryGetQueryString(getFieldValue(query, "query:" + STRING_SIG));
    }

    if (className.equals("com.datastax.driver.core.BatchStatement")) {
      final Object list = getFieldValue(query, "statements:Ljava/util/List;");
      if (list instanceof List) {
        return "<batch size: " + ((List)list).size() + ">";
      }
    }

    return "<unknown>";
  }
}
