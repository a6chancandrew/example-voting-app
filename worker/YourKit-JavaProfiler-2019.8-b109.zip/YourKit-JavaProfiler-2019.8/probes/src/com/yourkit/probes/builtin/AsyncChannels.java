/*
  Copyright (c) 2003-2019, YourKit
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

  * Neither the name of YourKit nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY YOURKIT "AS IS" AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL YOURKIT BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.yourkit.probes.builtin;

import com.yourkit.probes.*;
import com.yourkit.runtime.CallbackProxy;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.net.SocketAddress;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.WeakHashMap;
import java.util.concurrent.Future;

import static com.yourkit.probes.ReflectionUtil.OBJECT_SIG;
import static com.yourkit.probes.ReflectionUtil.getFieldValue;

public final class AsyncChannels {
  public static final String TABLE_NAME = "AsyncChannels";

  private static final MasterResourceRegistry<Object> ourChannels = new MasterResourceRegistry<Object>(
    AsyncChannels.class,
    TABLE_NAME,
    "Address" // column name
  ) {
    @Nullable
    @Override
    protected String retrieveResourceName(@NotNull final Object resource) {
      final SocketAddress address = getFieldValue(resource, "remoteAddress:Ljava/net/InetSocketAddress;");
      return getPresentableAddress(address);
    }
  };

  @Nullable
  private static String getPresentableAddress(@Nullable final SocketAddress address) {
    return address != null ? address.toString() : null;
  }

  private static long openChannel(final Object channel, @Nullable final String address, @Nullable final Throwable error) {
    if (channel == null) {
      return Table.NO_ROW;
    }

    // Open is a lasting event, but we are not interested in the time spent in opening, because it is asynchronous.
    // Instead, let's make it as short as possible by emulating enter and exit:

    final long resourceID = ourChannels.openOnEnter();
    ourChannels.openOnExit(
      resourceID,
      address,
      channel,
      error,
      FailedEventPolicy.DISCARD // use any value - it will not be used if exception is null
    );
    return resourceID;
  }

  private static final class BytesAndTimeTable extends Table {
    final LongColumn myBytes = new LongColumn("Bytes");
    final LongColumn myTimeMs = new LongColumn("Time (ms)");

    public BytesAndTimeTable(@NotNull final String name) {
      super(ourChannels.getResourceTable(), name, Table.MASK_FOR_POINT_EVENTS);
    }
  }

  private static final BytesAndTimeTable T_READ = new BytesAndTimeTable("Read");
  private static final BytesAndTimeTable T_WRITE = new BytesAndTimeTable("Write");

  private static final WeakHashMap<Future, AsyncOperation> ourFuture2Operation = new WeakHashMap<>();

  private interface AsyncOperation {
    void setResult(@NotNull final Future future, @Nullable final Object result);
  }

  private static final class ConnectOperation implements AsyncOperation {
    @Override
    public void setResult(@NotNull final Future future, @Nullable final Object result) {
      final Object channel = getFieldValue(future, "channel:Ljava/nio/channels/AsynchronousChannel;");
      if (channel instanceof AsynchronousSocketChannel) {
        openChannel(channel, null, null);
      }
    }
  }
  private static final ConnectOperation ourConnectOperation = new ConnectOperation();

  private static final class AcceptOperation implements AsyncOperation {
    @Override
    public void setResult(@NotNull final Future future, @Nullable final Object result) {
      if (result instanceof AsynchronousSocketChannel) {
        openChannel(result, null, null);
      }
    }
  }
  private static final AcceptOperation ourAcceptOperation = new AcceptOperation();

  private static final class ReadWriteOperation implements AsyncOperation {
    final int myRow;
    final long myStartMs;
    final BytesAndTimeTable myTable;

    @Nullable
    static ReadWriteOperation create(@NotNull final Object channel, @NotNull final BytesAndTimeTable table) {
      final int channelRow = ourChannels.getOrCreate(channel);
      final int row = table.createRow(channelRow);
      if (Table.shouldIgnoreRow(row)) {
        return null;
      }
      return new ReadWriteOperation(row, getTimeMs(), table);
    }

    public ReadWriteOperation(final int row, final long startTimeMs, @NotNull final BytesAndTimeTable table) {
      myRow = row;
      myStartMs = startTimeMs;
      myTable = table;
    }

    @Override
    public void setResult(@NotNull final Future future, @Nullable final Object result) {
      if (!(result instanceof Number)) {
        return;
      }
      final long bytes = ((Number)result).longValue();
      if (bytes >= 0) {
        myTable.myBytes.setValue(myRow, bytes);
      }
      final long timeMs = getTimeMs() - myStartMs;
      myTable.myTimeMs.setValue(myRow, timeMs);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:close()")
  public static final class AsyncChannel_close_Probe {
    public static int onEnter(@This final Object channel) {
      return ourChannels.closeOnEnter(channel);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      ourChannels.closeOnExit(rowIndex, e);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:connect(java.net.SocketAddress) java.util.concurrent.Future")
  public static final class AsyncChannel_connect_Future_Probe {
    public static void onReturn(@This final Object channel, @Param(1) final SocketAddress address, @ReturnValue final Future future) {
      if (future == null) {
        return;
      }
      synchronized (ourFuture2Operation) {
        // check isDone in lock
        if (!future.isDone()) {
          ourFuture2Operation.put(future, ourConnectOperation);
          return;
        }
      }
      // isDone is true - connected
      openChannel(channel, getPresentableAddress(address), null);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousServerSocketChannelImpl:accept() java.util.concurrent.Future")
  public static final class AsyncChannel_accept_Future_Probe {
    public static void onReturn(@ReturnValue final Future future) {
      if (future == null) {
        return;
      }
      if (future.isDone()) {
        final Object result = getFieldValue(future, "result:" + OBJECT_SIG);
        if (result != null) {
          ourAcceptOperation.setResult(future, result);
        }
        return;
      }
      synchronized (ourFuture2Operation) {
        ourFuture2Operation.put(future, ourAcceptOperation);
      }
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:read(java.nio.ByteBuffer) java.util.concurrent.Future")
  public static final class AsyncChannel_read_Future_Probe {
    public static Object onEnter(@This final Object channel) {
      return ReadWriteOperation.create(channel, T_READ);
    }

    public static void onExit(@ReturnValue @Nullable final Future future, @OnEnterResult @Nullable final Object operation) {
      beginReadWrite(future, (ReadWriteOperation)operation);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:write(java.nio.ByteBuffer) java.util.concurrent.Future")
  public static final class AsyncChannel_write_Future_Probe {
    public static Object onEnter(@This final Object channel) {
      return ReadWriteOperation.create(channel, T_WRITE);
    }

    public static void onExit(@ReturnValue @Nullable final Future future, @OnEnterResult @Nullable final Object operation) {
      beginReadWrite(future, (ReadWriteOperation)operation);
    }
  }

  private static void beginReadWrite(@Nullable final Future future, @Nullable final ReadWriteOperation operation) {
    if (future == null || operation == null) {
      return;
    }
    if (future.isDone()) {
      final Object result = getFieldValue(future, "result:" + OBJECT_SIG);
      if (result != null) {
        operation.setResult(future, result);
      }
      return;
    }
    synchronized (ourFuture2Operation) {
      ourFuture2Operation.put(future, operation);
    }
  }

  @MethodPattern("sun.nio.ch.PendingFuture:setResult(Object) void")
  public static final class PendingFuture_setResult_Probe {
    public static void onEnter(@This final Future future, @Param(1) final Object result) {
      final AsyncOperation operation;
      synchronized (ourFuture2Operation) {
        operation = ourFuture2Operation.remove(future);
      }
      if (operation != null) {
        operation.setResult(future, result);
      }
    }
  }

  @MethodPattern("sun.nio.ch.PendingFuture:setFailure(java.lang.Throwable) void")
  public static final class PendingFuture_setFailure_Probe {
    public static void onEnter(@This final Future future) {
      synchronized (ourFuture2Operation) {
        ourFuture2Operation.remove(future);
      }
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousServerSocketChannelImpl:accept(Object, java.nio.channels.CompletionHandler)")
  public static final class AsyncChannel_accept_Probe {
    @SuppressWarnings("unchecked")
    public static void onEnter(@Params @Out final Object[] params) {
      final Object handler = params[1];
      if (handler == null) {
        return;
      }
      final CompletionHandler<Object, Object> proxyHandler = new CompletionHandler<Object, Object>() {
        @Override
        public void completed(final Object channel, final Object attachment) {
          openChannel(channel, null, null);
          ((CompletionHandler)handler).completed(channel, attachment);
        }

        @Override
        public void failed(final Throwable error, final Object attachment) {
          ((CompletionHandler)handler).failed(error, attachment);
        }
      };
      params[1] = proxyHandler;
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:connect(java.net.SocketAddress, Object, java.nio.channels.CompletionHandler)")
  public static final class AsyncChannel_connect_Probe {
    @SuppressWarnings("unchecked")
    public static int onEnter(@This final Object channel, @Params @Out final Object[] params) {
      final SocketAddress address = (SocketAddress)params[0];
      final long resourceID = openChannel(channel, getPresentableAddress(address), null);
      if (resourceID == Table.NO_ROW) {
        // optimization
        return Table.NO_ROW;
      }

      final int openRow = ResourceRegistry.getOpenRow(resourceID);
      final Object handler = params[2];
      if (handler == null) {
        // the method will throw NPE, we will record it
        return openRow;
      }

      params[2] = new CompletionHandler<Object, Object>() {
        @Override
        public void completed(final Object result, final Object attachment) {
          ((CompletionHandler)handler).completed(result, attachment);
        }

        @Override
        public void failed(final Throwable e, final Object attachment) {
          if (e != null) {
            ourChannels.setOpenException(openRow, e);
          }
          ((CompletionHandler)handler).failed(e, attachment);
        }
      };

      return openRow;
    }

    public static void onExit(@OnEnterResult final int openRow, @ThrownException @Nullable final Throwable e) {
      if (e != null) {
        ourChannels.setOpenException(openRow, e);
      }
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:read(java.nio.ByteBuffer, long, java.util.concurrent.TimeUnit, Object, java.nio.channels.CompletionHandler)")
  public static final class AsyncChannel_read_1_Probe {
    public static void onEnter(@This final Object channel, @Params @Out final Object[] params) {
      final Object handler = params[4];
      if (handler == null) {
        return;
      }
      params[4] = beginReadWrite(channel, (CompletionHandler)handler, T_READ);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:read(java.nio.ByteBuffer[], int, int, long, java.util.concurrent.TimeUnit, Object, java.nio.channels.CompletionHandler)")
  public static final class AsyncChannel_read_2_Probe {
    public static void onEnter(@This final Object channel, @Params @Out final Object[] params) {
      final Object handler = params[6];
      if (handler == null) {
        return;
      }
      params[6] = beginReadWrite(channel, (CompletionHandler)handler, T_READ);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:write(java.nio.ByteBuffer, long, java.util.concurrent.TimeUnit, Object, java.nio.channels.CompletionHandler)")
  public static final class AsyncChannel_write_1_Probe {
    public static void onEnter(@This final Object channel, @Params @Out final Object[] params) {
      final Object handler = params[4];
      if (!(handler instanceof CompletionHandler)) {
        return;
      }
      params[4] = beginReadWrite(channel, (CompletionHandler)handler, T_WRITE);
    }
  }

  @MethodPattern("sun.nio.ch.AsynchronousSocketChannelImpl:write(java.nio.ByteBuffer[], int, int, long, java.util.concurrent.TimeUnit, Object, java.nio.channels.CompletionHandler)")
  public static final class AsyncChannel_write_2_Probe {
    public static void onEnter(@This final Object channel, @Params @Out final Object[] params) {
      final Object handler = params[6];
      if (!(handler instanceof CompletionHandler)) {
        return;
      }
      params[6] = beginReadWrite(channel, (CompletionHandler)handler, T_WRITE);
    }
  }

  @SuppressWarnings("unchecked")
  private static Object beginReadWrite(@NotNull final Object channel, @NotNull final CompletionHandler handler, @NotNull final BytesAndTimeTable table) {
    final int channelRow = ourChannels.getOrCreate(channel);
    final int row = table.createRow(channelRow);
    if (Table.shouldIgnoreRow(row)) {
      return handler;
    }
    final long startMs = getTimeMs();
    return new CompletionHandler() {
      @Override
      public void completed(final Object result, final Object attachment) {
        if (result instanceof Number) {
          final long value = ((Number)result).longValue();
          if (value > 0) {
            table.myBytes.setValue(row, value);
          }
        }
        table.myTimeMs.setValue(row, getTimeMs() - startMs);
        handler.completed(result, attachment);
      }

      @Override
      public void failed(final Throwable exc, final Object attachment) {
        handler.failed(exc, attachment);
      }
    };
  }

  private static long getTimeMs() {
    return CallbackProxy.getInstance().getUptimeMs();
  }
}
