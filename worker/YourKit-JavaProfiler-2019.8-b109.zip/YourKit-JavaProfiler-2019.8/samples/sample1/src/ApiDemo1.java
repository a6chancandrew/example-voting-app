import com.yourkit.api.Controller;

public class ApiDemo1 {
  public static void main(final String[] args) throws Exception {
    // Create the controller to profile the application itself.
    // To profile another application use Controller(String host, int port).
    final Controller controller = new Controller();

    final String snapshotFileName = controller.captureMemorySnapshot();
    System.out.println("Own memory snapshot captured: " + snapshotFileName);
  }
}
